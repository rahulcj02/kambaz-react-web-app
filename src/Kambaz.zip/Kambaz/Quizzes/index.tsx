export default function Piazza() {
    return (
        <h2>Quizzes</h2>
    );
}