export default function Settings() {
    return (
        <h2>Settings</h2>
    );
}