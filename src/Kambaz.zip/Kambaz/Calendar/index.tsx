export default function Calendar() {
    return (
        <h2>Calendar</h2>
    );
}