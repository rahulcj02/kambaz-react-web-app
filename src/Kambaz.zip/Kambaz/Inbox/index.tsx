export default function Inbox() {
    return (
        <h2>Inbox</h2>
    );
}